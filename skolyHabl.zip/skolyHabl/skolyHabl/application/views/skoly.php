<style>
    .form-inline{
        justify-content: center;
        
    }
    .vyhledat{
        justify-content: center;
    }
</style>



<div class="container">
   <br> 
   <title>Seznam škol</title> 
   <center><h1>Města s počtem přijatých žáků</h1></center>
    <br>

    
    <form class="form-inline" action="" method="post">
    
        <input type="text"  list="pocet" name="pocet" class="form-control">  
	<datalist id="pocet">                    
             <option value="Počet přijatých žáků">Počet přijatých žáků</option>      
	</datalist>
    <input class="btn btn-default" type="submit" name="Filtr" value="Filtrovat"> 
   
        <input class="form-control" type="text" name="title" value="" placeholder="Zadejte název města">
        <input class="btn btn-default" type="submit" name="submit" value="Vyhledat město"> 
    </form>
     </form>
    <div class="column">
            <div style="margin-top: 50px; background-color: blue">
                <table class="table table-lumen" style="" >
                    <thead>
                        <tr>
                            <th>Škola</th>
                            <th>Počet přijatých </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($skoly as $skola){
                             echo    "<tr>";
                             echo        "<td>", $skola->nazev, "</td>";
                             echo        "<td>", $skola->pocet, "</td>";
                             echo    "</tr>";
                        }
                        ?>
       
                    </tbody>
                </table>                 
        
            </div>

    </div>
</div>
</footer>