<div class="container mt-4">
    <h1 class="display-4 text-center">Přidání <span>školy</span></h1>
      <form id="book-form" method="post"> 
        <div class="form-group">     
            <label for="title">Název školy</label>
            <input type="text" id="title" class="form-control" name="nazev" required>
        </div>
           <div class="form-group">     
            <label for="mesto">Město</label>
            <input type="number" list="mesto" name="mesto" class="form-control" required>  
	<datalist id="mesto">        
            <?php foreach ($mesta as $mesto){  ?>
            <option value="<?php echo $mesto->id; ?>"> <?php echo $mesto->nazev; ?> </option>         
             <?php } ?>
	</datalist>  
        </div>
        <div class="form-group">
          <label for="author">Geo_lat školy</label>
    <input type="text" id="title" class="form-control" name="geo_lat" required>        
        </div>
        <div class="form-group">
          <label for="isbn">Geo_long školy</label>
          <input type="text" id="isbn" class="form-control" name="geo_long" required>
        </div>
        
          <input type="submit" value="Přidat školu" class="btn btn-primary btn-block" name="ulozit">
      </form>
      
  </div>
