<br>       
<title>Hlavní stránka</title>
<div class="container">
    <center><h1>Vítejte na hlavní stránce!</h1></center>
    <center><img src="https://lh3.googleusercontent.com/proxy/HaufIl8i-w8NwxAj-GpSDiilLktBw4pB8WYk7eUilb7M72crNqzjZfWCNztaHcj2XBMyohKPWhW4PRvmX9ZOj9GCVyDEO68v4sYb5n8LmK-OOgbvE2vbvIE"></center>      
            <br>
            <br>
            <br>
            <br>
          </footer>
        </div>

