<!DOCTYPE <html>
<html>
<head>  
    <title>Mapa škol</title>
 <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
 <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
 <style>
    #mapid { height: 500px; width: 600px; }
    
    .form-inline{
        justify-content: center;
        
    }
    .vyhledat{
        justify-content: center;
    }
</style>
</head>
<body>
<center>
     <br>
    <form class="form-inline" action="" method="post">
        <input class="form-control" type="text" name="title" value="" placeholder="Zadejte název města">
        <input class="btn btn-default" type="submit" name="submit" value="Vyhledat školu"> 
    </form>
    <br>
    <div id="mapid">
      
    </div>
    <script>  var mymap = L.map('mapid').setView([49.105, 17.49], 9);
            L.tileLayer('https://api.maptiler.com/maps/streets/{z}/{x}/{y}.png?key=h5JQdLM8HpZSOD9fU0Wj', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: 'your.mapbox.access.token'
}).addTo(mymap);
<?php foreach ($mapy as $mapa){ ?>
var marker = L.marker([<?php echo $mapa->geo_lat;?>, <?php echo $mapa->geo_long; ?>]).addTo(mymap);
marker.bindPopup("<b><?php echo str_replace(array("\n", "\r"), '', $mapa->nazev); ?> </b> <br>Počet přijatých žáků: <?php echo $mapa->pocet; ?> ").closePopup();
<?php } ?>
    </script>
    </center>
</footer>
</body>
</html>

