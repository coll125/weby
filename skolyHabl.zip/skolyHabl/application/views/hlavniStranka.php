<br>       
<div class="container">
    <center><img src="https://www.zskostelnihlavno.cz/assets/img/skola-1400px.jpg"></center>      
            <br>
            <br>
            <br>
            <br>
          
<footer class="page-footer font-small blue">
  <div class="footer-copyright text-center py-3">Lukáš Hábl 4.B
    
  </div>
</footer>
        </div>

