<div class="container">
   <br> 
    <center><h1>Města s počty přijatými žáky</h1></center> 

    <div class="column">
            <div style="margin-top: 50px; background-color: white">
                <table class="table table-lumen" style="" >
                    <thead>
                        <tr>
                            <th>Město</th>
                            <th>Škola</th>
                            <th>Počet přijatých</th>
                            <th>Obor</th>
                            <th>Rok</th>
                        
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($mesta as $mesto){
                            echo    "<tr>";
                            echo        "<td>", $mesto->nazev, "</td>";
                           /* echo        "<td>", $skola->skoly, "</td>";
                            echo        "<td>", $mesta->pocet_prijatych, "</td>";
                            echo        "<td>", $mesta->obor, "</td>";
                            echo        "<td><a href='"."'>Editace</a></td>";
                           */
                            echo    "</tr>";
                        }
                        ?>
       
                    </tbody>
                </table>                 
        
            </div>

    </div>
</div>
<footer class="page-footer font-small blue">
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href=""> Ondřej Konečný</a>
  </div>
</footer>