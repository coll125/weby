<?php

class model extends CI_Model {


    public function __construct() {
        parent::__construct();
    }
 public function get_mesta() {
        $query = $this->db->get("mesto"); 
        return $query->result(); 
    }
     public function get_skoly() {
        $query = $this->db->get("skola"); 
        return $query->result(); 
    }
}