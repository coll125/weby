# Codeigniter Ion Auth Tutorial
Codeigniter Ion Auth Library Integration - A step by step guide

**You will find the video tutorial guide here  - https://youtu.be/fucEtLz-PsI**


Ion Auth is a simple and lightweight authentication library for the CodeIgniter framework.

# Features

* Registration
* Login and Logout
* Forgotten Password
* Change Password Method
* User groups
* “Remember Me” funtionality
* Extremely Customizable
